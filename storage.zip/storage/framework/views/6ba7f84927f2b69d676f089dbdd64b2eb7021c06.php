<?php $__env->startSection('title', 'Dashboard - Supervisor'); ?>

<?php $__env->startSection('content'); ?>


<div class="main-body">
    <div class="page-wrapper">
        <div class="page-body">
            <div class="text-center">
                <h3>Monitoring Kebersihan dan Kerapihan Ruang Gedung A</h3>
                <p>Hari <?php echo e(Date::hari(now())); ?> Tanggal 12 November 2020 jam <?php echo e(Date::pukul(now())); ?> WIB</p>
            </div>
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $reports_today; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-6 col-xl-3">
                    <a href="">
                        <div class="card bg-c-green order-card">
                            <div class="card-block">
                                <h1 class="m-b-20">R.123</h1>
                                <p>SUDAH</p>
                                <h6><span class="ti-user mr-2"></span>Doni Kusuma</h6>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <div class="btn btn-block alert alert-dark" role="alert">
                        No Data
                    </div>
                </div>
                <?php endif; ?>
                
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kokeru\resources\views/supervisor/room.blade.php ENDPATH**/ ?>