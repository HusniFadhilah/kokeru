<?php $__env->startSection('title', 'Data - Cleaning Service'); ?>

<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">

                <div class="page-body">
                    <div class="row">

                        <!-- tabs card start -->
                        <div class="col-sm-12">
                            <a href="<?php echo e(route('supervisor.cs.create')); ?>" class="btn btn-primary mb-3"><i class="fa fa-plus mr-2"></i>Tambah Karyawan Baru</a>
                            <div class="card tabs-card">
                                <div class="card-block">
                                    <div class="table-responsive">
                                        <table class="table datatable">
                                            <tr>
                                                <th>No</th>
                                                <th>Nama</th>
                                                <th>Avatar</th>
                                                <th>Action</th>
                                            </tr>
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                                <td><?php echo e($user->name); ?></td>
                                                <td><?php if(isset($user->avatar)): ?><img src="<?php echo e(asset('storage/'.$user->avatar)); ?>" style="max-width:80px"><?php endif; ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('supervisor.cs.edit', $user->id)); ?>" class="btn btn-warning btn-sm" title="Edit CS"><i class="fa fa-edit"></i></a>
                                                    <a href="<?php echo e(route('supervisor.cs.delete',$user->id)); ?>" class="btn btn-danger btn-sm tombol-hapus" data-text="Karyawan" title="Delete CS"><i class="fa fa-trash"></i></a>
                                                    <form id="delete-form" action="" method="POST" class="d-none">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('delete'); ?>
                                                    </form>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- tabs card end -->

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kokeru\resources\views/supervisor/crud_cs/index.blade.php ENDPATH**/ ?>