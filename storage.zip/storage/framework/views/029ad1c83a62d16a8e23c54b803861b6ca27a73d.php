<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Kebersihan</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <div class="container-fluid">
        <div class="text-center title">
            <h4>
                Laporan Harian Kebersihan dan Kerapihan Ruangan Gedung Bersama Maju<br>
                Hari <?php echo e(Date::hari($date)); ?> Tanggal <?php echo e(Date::indo_date($date)); ?>

            </h4>
            <div class="row">
                <div class="col-align-center">
                    <small>
                        &lt;&lt;Tanggal Cetak <?php echo e(Date::indo_date(now())); ?> Pukul <?php echo e(Date::pukul(now())); ?>&gt;&gt;
                    </small>
                </div>
                <?php if($status != ''): ?>
                <div class="float-right">
                    <small>
                        <span class="mb-1">Status:</span>
                        <span class="badge badge-<?php echo e($status == 1 ? 'success' : 'danger'); ?>"><?php echo e($status == 1 ? 'SUDAH' : 'BELUM'); ?></span>
                    </small>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <?php if(count($reports) > 0): ?>
                <table class="table" border="1">
                    <thead>
                        <tr style="text-align: center;background-color: gray;">
                            <th scope=" col">No</th>
                            <th scope="col">Ruang</th>
                            <th scope="col">Nama CS</th>
                            <th scope="col">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr style="text-align: center;">
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($report->room['name']); ?></td>
                            <td><?php echo e($report->user['name']); ?></td>
                            <td><?php echo e($report->status==0? "BELUM":"SUDAH"); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php else: ?>
                <div class="col-12">
                    <div class="btn btn-block alert alert-dark" role="alert">
                        No Data
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="row">
            <div class="col-align-right">
                <div class="float-right">
                    <h5>Approval</h5>
                    <p>ttd</p>
                    <h5>Arif Sutowo</h5>
                    <h5>Manajer.</h5>
                </div>
            </div>
        </div>
    </div>

</body>

</html>
<?php /**PATH D:\kokeru\resources\views/supervisor/report/pdf.blade.php ENDPATH**/ ?>