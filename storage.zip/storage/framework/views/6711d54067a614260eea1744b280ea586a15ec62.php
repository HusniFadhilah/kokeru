<?php $__env->startSection('title', 'Dashboard - Supervisor'); ?>

<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">
                    <div class="row">

                        <!-- order-card start -->
                        <div class="col-md-6 col-xl-3">
                            <div class="card bg-c-blue order-card">
                                <div class="card-block">
                                    <h6 class="m-b-20">Jumlah Karyawan</h6>
                                    <h2 class="text-right"><i class="ti-user f-left"></i><span><?php echo e($sum_cs); ?></span></h2>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-xl-3">
                            <div class="card bg-c-yellow order-card">
                                <div class="card-block">
                                    <h6 class="m-b-20">Jumlah Ruangan</h6>
                                    <h2 class="text-right"><i class="ti-location-pin f-left"></i><span><?php echo e($sum_room); ?></span></h2>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-xl-3">
                            <div class="card bg-c-green order-card">
                                <div class="card-block">
                                    <h6 class="m-b-20">Sudah Dibersihkan</h6>
                                    <h2 class="text-right"><i class="ti-check f-left"></i><span><?php echo e($sum_status_sudah); ?></span></h2>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-xl-3">
                            <div class="card bg-c-pink order-card">
                                <div class="card-block">
                                    <h6 class="m-b-20">Belum Dibersihkan</h6>
                                    <h2 class="text-right"><i class="ti-close f-left"></i><span><?php echo e($sum_status_belum); ?></span></h2>
                                </div>
                            </div>
                        </div>
                        <!-- order-card end -->

                        <!-- tabs card start -->
                        <div class="col-sm-12">
                            <div class="card tabs-card">
                                <div class="card-block p-0">
                                    <!-- Nav tabs -->
                                    <ul class="nav nav-tabs md-tabs" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active" data-toggle="tab" href="#today" role="tab"><i class="fa fa-calendar"></i>Hari ini</a>
                                            <div class="slide"></div>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" data-toggle="tab" href="#all" role="tab"><i class="fa fa-globe"></i>Semua</a>
                                            <div class="slide"></div>
                                        </li>
                                    </ul>
                                    <!-- Tab panes -->
                                    <div class="tab-content card-block table-border-style">
                                        <div class="tab-pane active" id="today" role="tabpanel">

                                            <div class="table-responsive table-hover">
                                                <table class="datatable">
                                                    <thead>
                                                        <tr>
                                                            <th>No</th>
                                                            <th>Nama</th>
                                                            <th>Ruangan</th>
                                                            <th>Tanggal</th>
                                                            <th>Status</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $reports_today; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($loop->iteration); ?></td>
                                                            <td><?php echo e($report->user->name); ?></td>
                                                            <td><?php echo e($report->room->name); ?></td>
                                                            <td><?php echo e(Date::indo_date($report->date_time)); ?></td>
                                                            <td>
                                                                <?php if($report->status == 0): ?>
                                                                <span class="label label-danger">Belum</span>
                                                                <?php else: ?>
                                                                <span class="label label-success">Sudah</span>
                                                                <?php endif; ?>
                                                            </td>
                                                            <td>
                                                                <button class="btn btn-sm btn-primary trigger-modal" data-cs="<?php echo e($report->user['name']); ?>" data-room="<?php echo e($report->room['name']); ?>" data-file1="<?php echo e(asset('storage/'.$report->file_1)); ?>" data-file2="<?php echo e(asset('storage/'.$report->file_2)); ?>" data-file3="<?php echo e(asset('storage/'.$report->file_3)); ?>" data-file4="<?php echo e(asset('storage/'.$report->file_4)); ?>" data-file5="<?php echo e(asset('storage/'.$report->file_5)); ?>" data-video="<?php echo e(asset('storage/'.$report->video)); ?>" data-toggle="modal" data-target="#modal">
                                                                    <i class="fa fa-eye mr-2"></i>Lihat Bukti
                                                                </button>
                                                            </td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>

                                        <div class="tab-pane" id="all" role="tabpanel">
                                            <div class="table-responsive table-hover">
                                                <table class="datatable">
                                                    <thead>
                                                        <tr>
                                                            <th>No</th>
                                                            <th>Nama</th>
                                                            <th>Ruangan</th>
                                                            <th>Tanggal</th>
                                                            <th>Status</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($loop->iteration); ?></td>
                                                            <td><?php echo e($report->user->name); ?></td>
                                                            <td><?php echo e($report->room->name); ?></td>
                                                            <td><?php echo e(Date::indo_date($report->date_time)); ?></td>
                                                            <td>
                                                                <?php if($report->status == 0): ?>
                                                                <span class="label label-danger">Belum</span>
                                                                <?php else: ?>
                                                                <span class="label label-success">Sudah</span>
                                                                <?php endif; ?>
                                                            </td>
                                                            <td>
                                                                <button class="btn btn-sm btn-primary trigger-modal" data-cs="<?php echo e($report->user['name']); ?>" data-room="<?php echo e($report->room['name']); ?>" data-file1="<?php echo e(asset('storage/'.$report->file_1)); ?>" data-file2="<?php echo e(asset('storage/'.$report->file_2)); ?>" data-file3="<?php echo e(asset('storage/'.$report->file_3)); ?>" data-file4="<?php echo e(asset('storage/'.$report->file_4)); ?>" data-file5="<?php echo e(asset('storage/'.$report->file_5)); ?>" data-video="<?php echo e(asset('storage/'.$report->video)); ?>" data-toggle="modal" data-target="#modal">
                                                                    <i class="fa fa-eye mr-2"></i>Lihat Bukti
                                                                </button>
                                                            </td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>


                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- tabs card end -->

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kokeru\resources\views/supervisor/index.blade.php ENDPATH**/ ?>