<?php $__env->startSection('title', 'Selesaikan Tugas - CS'); ?>

<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">

                <div class="page-body">
                    <div class="text-center">
                        <h3>Monitoring Kebersihan dan Kerapihan Ruangan</h3>
                        <p>Hari <?php echo e(Date::hari(now())); ?> <?php echo e(Date::tanggal(now())); ?> <?php echo e(Date::Bulan(now())); ?> <?php echo e(Date::tahun(now())); ?> jam <?php echo e(Date::pukul(now())); ?> WIB</p>
                    </div>
                    <div class="row">

                        <!-- tabs card start -->
                        <div class="col-sm-12">
                            <div class="card tabs-card">
                                <div class="card-block">

                                    <div class="table-responsive table-hover">
                                        <table class="datatable">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Nama</th>
                                                    <th>Ruangan</th>
                                                    <th>Tanggal</th>
                                                    <th>Status</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $reports_today; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($report->user->name); ?></td>
                                                    <td><?php echo e($report->room->name); ?></td>
                                                    <td><?php echo e(Date::indo_date($report->date_time)); ?></td>
                                                    <td>
                                                        <?php if($report->status == 0): ?>
                                                        <span class="label label-danger">Belum</span>
                                                        <?php else: ?>
                                                        <span class="label label-success">Sudah</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($report->status == 0): ?>
                                                        <a href="<?php echo e(route('cs.report.edit',$report->id)); ?>" class="btn btn-sm btn-info"><i class="fa fa-upload mr-2"></i>Upload Bukti</a>
                                                        <?php else: ?>
                                                        <button class="btn btn-sm btn-primary trigger-modal" data-cs="<?php echo e($report->user['name']); ?>" data-room="<?php echo e($report->room['name']); ?>" data-file1="<?php echo e(asset('storage/'.$report->file_1)); ?>" data-file2="<?php echo e(asset('storage/'.$report->file_2)); ?>" data-file3="<?php echo e(asset('storage/'.$report->file_3)); ?>" data-file4="<?php echo e(asset('storage/'.$report->file_4)); ?>" data-file5="<?php echo e(asset('storage/'.$report->file_5)); ?>" data-video="<?php echo e(asset('storage/'.$report->video)); ?>" data-toggle="modal" data-target="#modal">
                                                            <i class="fa fa-eye mr-2"></i>Lihat Bukti
                                                        </button>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- tabs card end -->

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kokeru\resources\views/cs/report/index.blade.php ENDPATH**/ ?>