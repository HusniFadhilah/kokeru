<?php $__env->startSection('title', 'Selesaikan Tugas - CS'); ?>

<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">

                <div class="page-body">
                    <div class="text-center">
                        <h3>Monitoring Kebersihan dan Kerapihan Ruangan</h3>
                        <p>Hari <?php echo e(Date::hari(now())); ?> <?php echo e(Date::tanggal(now())); ?> <?php echo e(Date::Bulan(now())); ?> <?php echo e(Date::tahun(now())); ?> jam <?php echo e(Date::pukul(now())); ?> WIB</p>
                    </div>
                    <div class="row">

                        <!-- tabs card start -->
                        <div class="col-sm-12">
                            <div class="card tabs-card">
                                <div class="card-block p-0">
                                    <!-- Nav tabs -->
                                    <ul class="nav nav-tabs md-tabs" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active" data-toggle="tab" href="#today" role="tab"><i class="fa fa-calendar"></i>Hari ini</a>
                                            <div class="slide"></div>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" data-toggle="tab" href="#all" role="tab"><i class="fa fa-globe"></i>Semua</a>
                                            <div class="slide"></div>
                                        </li>
                                    </ul>
                                    <!-- Tab panes -->
                                    <div class="tab-content card-block table-border-style">
                                        <div class="tab-pane active" id="today" role="tabpanel">

                                            <div class="table-responsive table-hover">
                                                <table class="datatable">
                                                    <thead>
                                                        <tr>
                                                            <th>No</th>
                                                            <th>Nama</th>
                                                            <th>Ruangan</th>
                                                            <th>Tanggal</th>
                                                            <th>Status</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $reports_today; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($loop->iteration); ?></td>
                                                            <td><?php echo e($report->user->name); ?></td>
                                                            <td><?php echo e($report->room->name); ?></td>
                                                            <td><?php echo e(Date::indo_date($report->date_time)); ?></td>
                                                            <td>
                                                                <?php if($report->status == 0): ?>
                                                                <span class="label label-danger">Belum</span>
                                                                <?php else: ?>
                                                                <span class="label label-success">Sudah</span>
                                                                <?php endif; ?>
                                                            </td>
                                                            <td>
                                                                <?php if($report->status == 0): ?>
                                                                <a href="<?php echo e(route('cs.task.edit',$report->id)); ?>" class="btn btn-sm btn-warning">Upload Bukti</a>
                                                                <?php endif; ?>
                                                            </td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- tabs card end -->

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kokeru\resources\views/cs/task/index.blade.php ENDPATH**/ ?>