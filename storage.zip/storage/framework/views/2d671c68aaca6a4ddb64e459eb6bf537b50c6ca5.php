<?php $__env->startSection('title', 'Data - Jadwal'); ?>

<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">

                <div class="page-body">
                    <div class="row">

                        <!-- tabs card start -->
                        <div class="col-sm-12">
                            <a href="<?php echo e(route('supervisor.schedule.create')); ?>" class="btn btn-primary mb-3"><i class="fa fa-plus mr-2"></i>Tambah Jadwal Baru</a>
                            
                            <div class="card tabs-card">
                                <div class="card-block">
                                    <div class="table-responsive">
                                        <table class="datatable">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Nama Ruangan</th>
                                                    <th>Karyawan</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                                                    <td><?php echo e($schedule->room['name']); ?></td>
                                                    <td><?php echo e($schedule->user['name']); ?></td>
                                                    <td>
                                                        <a href="<?php echo e(route('supervisor.schedule.edit', $schedule->id)); ?>" class="btn btn-warning btn-sm" title="Edit Ruangan"><i class="fa fa-edit"></i></a>
                                                        <a href="<?php echo e(route('supervisor.schedule.delete',$schedule->id)); ?>" class="btn btn-danger btn-sm tombol-hapus" data-text="Jadwal" title="Hapus Jadwal"><i class="fa fa-trash"></i></a>
                                                        <form id="delete-form" action="" method="POST" class="d-none">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('delete'); ?>
                                                        </form>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- tabs card end -->

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kokeru\resources\views/supervisor/schedule/index.blade.php ENDPATH**/ ?>