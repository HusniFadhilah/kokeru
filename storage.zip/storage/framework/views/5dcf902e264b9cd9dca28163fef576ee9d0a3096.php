<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/img/logo/logo.ico')); ?>" />

    <!-- Custom styles for this template-->
    <!-- Google font-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600" rel="stylesheet">
    <!-- Required Fremwork -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap/css/bootstrap.min.css')); ?>">
    <!-- themify-icons line icon -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/icon/themify-icons/themify-icons.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/icon/font-awesome/css/font-awesome.min.css')); ?>">
    <!-- ico font -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/icon/icofont/css/icofont.css')); ?>">
    <!-- Style.css -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/jquery.mCustomScrollbar.css')); ?>">
</head>

<body class="">

    <!-- Pre-loader start -->
    <div class="theme-loader">
        <div class="loader-track">
            <div class="loader-bar"></div>
        </div>
    </div>
    <!-- Pre-loader end -->
    <div id="pcoded" class="pcoded">
        <div class="pcoded-overlay-box"></div>
        <div class="pcoded-container navbar-wrapper">
            <?php echo $__env->make('layouts/template/supervisor-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>

    </div>
    </div>

    <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/popper.js/popper.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <!-- jquery slimscroll js -->
    <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery-slimscroll/jquery.slimscroll.js')); ?>"></script>
    <!-- modernizr js -->
    <script type="text/javascript" src="<?php echo e(asset('assets/js/modernizr/modernizr.js')); ?>"></script>
    <!-- am chart -->
    <script src="<?php echo e(asset('assets/pages/widget/amchart/amcharts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/pages/widget/amchart/serial.min.js')); ?>"></script>
    <!-- Chart js -->
    <script type="text/javascript" src="<?php echo e(asset('assets/js/chart.js/Chart.js')); ?>"></script>
    <!-- Todo js -->
    <script type="text/javascript " src="<?php echo e(asset('assets/pages/todo/todo.js')); ?> "></script>
    <!-- Custom js -->
    <script type="text/javascript" src="<?php echo e(asset('assets/pages/dashboard/custom-dashboard.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
    <script type="text/javascript " src="<?php echo e(asset('assets/js/SmoothScroll.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/pcoded.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vartical-demo.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>

</body>

</html>
<?php /**PATH D:\kokeru-belajar\resources\views/layouts/default.blade.php ENDPATH**/ ?>