<?php $__env->startSection('title', 'Upload Task'); ?>

<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">

                <div class="page-body">

                    <div class="card tabs-card">
                        <div class="card-block">
                            <div class="container">
                                <h4 class="sub-title">Tambah Foto atau Video Kebersihan</h4>
                                <p>Ruangan: <b><?php echo e($report->room['name']); ?></b></p>
                                <?php if($errors->any()): ?>
                                <div class="card borderless-card">
                                    <div class="card-block danger-breadcrumb">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <form action="<?php echo e(route('cs.report.update', $report->id)); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('patch'); ?>
                                    <div class="form-group row">
                                        <label class="col-lg-2 col-form-label label-image">Foto Bukti</label>
                                        <div class="col-lg-10">
                                            <input type="file" class="form-control <?php $__errorArgs = ['foto[]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="foto[]" id="file-input" multiple>
                                        </div>
                                        <div class="col-lg-2"></div>
                                        <div class="col-lg-10">
                                            <div id="preview" class="mt-2"></div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-lg-2 col-form-label label-image">Video Bukti</label>
                                        <div class="col-lg-10">
                                            <input type="file" class="form-control <?php $__errorArgs = ['video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="video" id="video" accept="video/*">
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-2"></div>
                                        <div class="col-lg-10">
                                            <video width="400" controls>
                                                <source src="mov_bbb.mp4" id="video_here">
                                                Your browser does not support HTML5 video.
                                            </video>
                                        </div>
                                    </div>
                                    <div class="form-group mt-4">
                                        <button type="submit" class="btn btn-success"><i class="fa fa-plus"></i> Tambah</button>
                                        <a href="<?php echo e(route('cs.report.data')); ?>" id="back" class="btn btn-danger"><i class="fa fa-times"></i> Batal</a>
                                    </div>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kokeru\resources\views/cs/report/edit.blade.php ENDPATH**/ ?>