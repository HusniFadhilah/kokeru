<?php $__env->startSection('title', 'Dashboard - Cleaning Service'); ?>

<?php $__env->startSection('content'); ?>
<div class="pcoded-content">
    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
                <div class="page-body">
                    <div class="text-center">
                        <h3>Monitoring Kebersihan dan Kerapihan Ruangan</h3>
                        <p>Hari <?php echo e(Date::hari(now())); ?> <?php echo e(Date::tanggal(now())); ?> <?php echo e(Date::Bulan(now())); ?> <?php echo e(Date::tahun(now())); ?> jam <?php echo e(Date::pukul(now())); ?> WIB</p>
                    </div>
                    <div class="row">
                        <?php $__empty_1 = true; $__currentLoopData = $reports_today; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-md-6 col-xl-3">
                            <a href="" class="trigger-modal" data-cs="<?php echo e($report->user['name']); ?>" data-room="<?php echo e($report->room['name']); ?>" data-file1="<?php echo e(asset('storage/'.$report->file_1)); ?>" data-file2="<?php echo e(asset('storage/'.$report->file_2)); ?>" data-file3="<?php echo e(asset('storage/'.$report->file_3)); ?>" data-file4="<?php echo e(asset('storage/'.$report->file_4)); ?>" data-file5="<?php echo e(asset('storage/'.$report->file_5)); ?>" data-video="<?php echo e(asset('storage/'.$report->video)); ?>" data-toggle="modal" data-target="#modal">
                                <div class="card bg-c-<?php echo e($report->status==0? 'pink':'green'); ?> order-card">
                                    <div class="card-block">
                                        <h1 class="m-b-20"><?php echo e($report->room['name']); ?></h1>
                                        <p><?php echo e($report->status==0? "BELUM":"SUDAH"); ?></p>
                                        <h6><span class="ti-user mr-2"></span><?php echo e($report->user['name']); ?></h6>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12">
                            <div class="btn btn-block alert alert-dark" role="alert">
                                No Data
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kokeru\resources\views/cs/index.blade.php ENDPATH**/ ?>